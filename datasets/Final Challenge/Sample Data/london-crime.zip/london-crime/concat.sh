for d in * ; do
    cat "$d/$d-city-of-london-street.csv" >> city-of-london-street.csv
    cat "$d/$d-city-of-london-outcomes.csv" >> city-of-london-outcomes.csv
    cat "$d/$d-city-of-london-stop-and-search.csv" >> city-of-london-stop-and-search.csv
done
